package utils;

import java.util.List;

// Ensure the correct package path for the Device class
import devices.Device; // Update this to the correct package where Device is located

// Energy monitoring utility
public class EnergyMonitor {
    public static double calculateTotalPowerConsumption(List<Device> devices) {
        return devices.stream()
                .filter(Device::isOn)
                .mapToDouble(Device::getPowerConsumption)
                .sum();
    }

    public static String getEnergyReport(List<Device> devices) {
        double total = calculateTotalPowerConsumption(devices);
        StringBuilder report = new StringBuilder();
        report.append("\n=== Energy Consumption Report ===\n");
        report.append(String.format("Total Power Consumption: %.2f kW\n", total));
        report.append("Devices consuming power:\n");
        
        devices.stream()
                .filter(Device::isOn)
                .forEach(device -> 
                    report.append(String.format("- %s: %.2f kW\n", 
                            device.getName(), device.getPowerConsumption())));
        
        return report.toString();
    }

    // Method with varargs for calculating consumption of specific devices
    public static double calculateConsumptionForDevices(Device... devices) {
        double total = 0;
        for (Device device : devices) {
            if (device.isOn()) {
                total += device.getPowerConsumption();
            }
        }
        return total;
    }
}





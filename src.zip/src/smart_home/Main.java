
import automation.*;
import devices.*;
import users.*;
import utils.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;

public class Main {
    private static List<Device> devices = new ArrayList<>();
    private static List<User> users = new ArrayList<>();
    private static List<Automation> automations = new ArrayList<>();
    private static User currentUser = null;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        initializeSystem();
        displayWelcomeScreen();
    }

    private static void initializeSystem() {
        // Create some default devices
        devices.add(new Light("Living Room Light", "Living Room"));
        devices.add(new Fan("Bedroom Fan", "Bedroom"));
        devices.add(new AC("Main AC", "Living Room"));
        devices.add(new SecurityCamera("Front Door Camera", "Entrance"));
        devices.add(new SmartPlug("TV Plug", "Living Room"));

        // Create some users
        users.add(new RegularUser("john", "password123", "john@example.com"));
        users.add(new Admin("admin", "admin123", "admin@smarthome.com", 3));

        // Create an automation
        MotionDetector motionDetector = new MotionDetector("Entryway Motion", 30);
        motionDetector.addDevice(devices.get(0)); // Living Room Light
        automations.add(motionDetector);

        // Start automation threads
        new Thread(motionDetector).start();

        // Load previous state from file if exists
        loadSystemState();
    }

    private static void displayWelcomeScreen() {
        while (true) {
            System.out.println("\n=== Smart Home Automation System ===");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        loginUser();
                        break;
                    case 2:
                        saveSystemState();
                        System.out.println("Exiting system. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            } catch (Exception e) {
                Logger.logError("Unexpected error: " + e.getMessage());
            }
        }
    }

    private static void loginUser() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        for (User user : users) {
            if (user.getUsername().equals(username) && user.authenticate(password)) {
                currentUser = user;
                System.out.println("Login successful! Welcome, " + username + ".");
                userDashboard();
                return;
            }
        }
        System.out.println("Invalid username or password.");
    }

    private static void userDashboard() {
        while (currentUser != null) {
            currentUser.displayDashboard();
            
            if (currentUser instanceof Admin) {
                displayAdminMenu();
            } else {
                displayRegularUserMenu();
            }
        }
    }

    private static void displayRegularUserMenu() {
        System.out.println("\nRegular User Menu:");
        System.out.println("1. Control Devices");
        System.out.println("2. View Device Status");
        System.out.println("3. View Energy Consumption");
        System.out.println("4. Add Favorite Devices");
        System.out.println("5. Logout");
        System.out.print("Choose an option: ");

        try {
            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    controlDevices();
                    break;
                case 2:
                    viewDeviceStatus();
                    break;
                case 3:
                    viewEnergyConsumption();
                    break;
                case 4:
                    addFavoriteDevices();
                    break;
                case 5:
                    currentUser.logout();
                    currentUser = null;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
        } catch (Exception e) {
            Logger.logError("Unexpected error: " + e.getMessage());
        }
    }

    private static void displayAdminMenu() {
        System.out.println("\nAdmin Menu:");
        System.out.println("1. Control Devices");
        System.out.println("2. View Device Status");
        System.out.println("3. View Energy Consumption");
        System.out.println("4. Manage Automations");
        System.out.println("5. Manage Users");
        System.out.println("6. System Diagnostics");
        System.out.println("7. Logout");
        System.out.print("Choose an option: ");

        try {
            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    controlDevices();
                    break;
                case 2:
                    viewDeviceStatus();
                    break;
                case 3:
                    viewEnergyConsumption();
                    break;
                case 4:
                    manageAutomations();
                    break;
                case 5:
                    manageUsers();
                    break;
                case 6:
                    ((Admin)currentUser).systemDiagnostics();
                    break;
                case 7:
                    currentUser.logout();
                    currentUser = null;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
        } catch (Exception e) {
            Logger.logError("Unexpected error: " + e.getMessage());
        }
    }

    private static void controlDevices() {
        System.out.println("\nAvailable Devices:");
        for (int i = 0; i < devices.size(); i++) {
            System.out.println((i + 1) + ". " + devices.get(i).getName() + " (" + devices.get(i).getLocation() + ")");
        }
        System.out.print("Select a device (0 to cancel): ");
        
        try {
            int deviceChoice = Integer.parseInt(scanner.nextLine());
            if (deviceChoice > 0 && deviceChoice <= devices.size()) {
                Device selectedDevice = devices.get(deviceChoice - 1);
                System.out.println("\n" + selectedDevice.getStatus());
                
                System.out.println("1. Turn On");
                System.out.println("2. Turn Off");
                System.out.println("3. Adjust Settings");
                System.out.println("4. Back");
                System.out.print("Choose an action: ");
                
                int actionChoice = Integer.parseInt(scanner.nextLine());
                switch (actionChoice) {
                    case 1:
                        selectedDevice.turnOn();
                        break;
                    case 2:
                        selectedDevice.turnOff();
                        break;
                    case 3:
                        adjustDeviceSettings(selectedDevice);
                        break;
                    case 4:
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } else if (deviceChoice != 0) {
                System.out.println("Invalid device selection.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
        }
    }

    private static void adjustDeviceSettings(Device device) {
        System.out.println("\nAdjusting settings for " + device.getName());
        
        if (device instanceof Light) {
            System.out.println("1. Set Brightness");
            System.out.println("2. Set Color");
            System.out.print("Choose setting to adjust: ");
            
            int settingChoice = Integer.parseInt(scanner.nextLine());
            switch (settingChoice) {
                case 1:
                    System.out.print("Enter brightness (0-100): ");
                    int brightness = Integer.parseInt(scanner.nextLine());
                    device.adjustSetting("brightness", brightness);
                    break;
                case 2:
                    System.out.print("Enter color: ");
                    String color = scanner.nextLine();
                    device.adjustSetting("color", color);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else if (device instanceof Fan) {
            System.out.println("1. Set Speed");
            System.out.println("2. Toggle Oscillation");
            System.out.print("Choose setting to adjust: ");
            
            int settingChoice = Integer.parseInt(scanner.nextLine());
            switch (settingChoice) {
                case 1:
                    System.out.print("Enter speed (0-5): ");
                    int speed = Integer.parseInt(scanner.nextLine());
                    device.adjustSetting("speed", speed);
                    break;
                case 2:
                    System.out.print("Toggle oscillation (true/false): ");
                    boolean oscillation = Boolean.parseBoolean(scanner.nextLine());
                    device.adjustSetting("oscillation", oscillation);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else if (device instanceof AC) {
            System.out.println("1. Set Temperature");
            System.out.println("2. Set Mode");
            System.out.println("3. Set Fan Speed");
            System.out.print("Choose setting to adjust: ");
            
            int settingChoice = Integer.parseInt(scanner.nextLine());
            switch (settingChoice) {
                case 1:
                    System.out.print("Enter temperature: ");
                    int temp = Integer.parseInt(scanner.nextLine());
                    device.adjustSetting("temperature", temp);
                    break;
                case 2:
                    System.out.print("Enter mode (Cool/Heat/Auto/Fan): ");
                    String mode = scanner.nextLine();
                    device.adjustSetting("mode", mode);
                    break;
                case 3:
                    System.out.print("Enter fan speed (1-5): ");
                    int fanSpeed = Integer.parseInt(scanner.nextLine());
                    device.adjustSetting("fanspeed", fanSpeed);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else if (device instanceof SecurityCamera) {
            System.out.println("1. Toggle Recording");
            System.out.println("2. Toggle Motion Detection");
            System.out.println("3. Set Recording Quality");
            System.out.print("Choose setting to adjust: ");
            
            int settingChoice = Integer.parseInt(scanner.nextLine());
            switch (settingChoice) {
                case 1:
                    System.out.print("Toggle recording (true/false): ");
                    boolean recording = Boolean.parseBoolean(scanner.nextLine());
                    device.adjustSetting("recording", recording);
                    break;
                case 2:
                    System.out.print("Toggle motion detection (true/false): ");
                    boolean motionDetect = Boolean.parseBoolean(scanner.nextLine());
                    device.adjustSetting("motiondetection", motionDetect);
                    break;
                case 3:
                    System.out.print("Enter quality (HD/FullHD/4K): ");
                    String quality = scanner.nextLine();
                    device.adjustSetting("quality", quality);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else if (device instanceof SmartPlug) {
            System.out.println("1. Connect Device");
            System.out.print("Choose setting to adjust: ");
            
            int settingChoice = Integer.parseInt(scanner.nextLine());
            if (settingChoice == 1) {
                System.out.print("Enter device power consumption (kW): ");
                double power = Double.parseDouble(scanner.nextLine());
                ((SmartPlug)device).connectDevice(power);
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private static void viewDeviceStatus() {
        System.out.println("\n=== Device Status ===");
        for (Device device : devices) {
            System.out.println(device.getStatus());
        }
    }

    private static void viewEnergyConsumption() {
        System.out.println(EnergyMonitor.getEnergyReport(devices));
    }

    private static void addFavoriteDevices() {
        if (currentUser instanceof RegularUser) {
            System.out.println("\nAvailable Devices:");
            for (int i = 0; i < devices.size(); i++) {
                System.out.println((i + 1) + ". " + devices.get(i).getName());
            }
            System.out.print("Select devices to add as favorites (comma separated, 0 to cancel): ");
            
            String input = scanner.nextLine();
            if (!input.equals("0")) {
                String[] selections = input.split(",");
                String[] deviceNames = new String[selections.length];
                
                for (int i = 0; i < selections.length; i++) {
                    int index = Integer.parseInt(selections[i].trim()) - 1;
                    if (index >= 0 && index < devices.size()) {
                        deviceNames[i] = devices.get(index).getName();
                    }
                }
                
                ((RegularUser)currentUser).addFavoriteDevices(deviceNames);
                System.out.println("Devices added to favorites.");
            }
        }
    }

    private static void manageAutomations() {
        if (currentUser instanceof Admin) {
            System.out.println("\n=== Automations Management ===");
            for (int i = 0; i < automations.size(); i++) {
                Automation automation = automations.get(i);
                System.out.println((i + 1) + ". " + automation.name + 
                        " (" + (automation.isActive ? "Active" : "Inactive") + ")");
                
                if (automation instanceof AutomationRule) {
                    System.out.println("   Description: " + ((AutomationRule)automation).getDescription());
                }
            }
            
            System.out.println("1. Toggle Automation");
            System.out.println("2. Add Device to Automation");
            System.out.println("3. Back");
            System.out.print("Choose an action: ");
            
            int actionChoice = Integer.parseInt(scanner.nextLine());
            switch (actionChoice) {
                case 1:
                    System.out.print("Select automation to toggle: ");
                    int autoIndex = Integer.parseInt(scanner.nextLine()) - 1;
                    if (autoIndex >= 0 && autoIndex < automations.size()) {
                        Automation auto = automations.get(autoIndex);
                        auto.setActive(!auto.isActive);
                    }
                    break;
                case 2:
                    System.out.print("Select automation to add device to: ");
                    int autoChoice = Integer.parseInt(scanner.nextLine()) - 1;
                    if (autoChoice >= 0 && autoChoice < automations.size()) {
                        System.out.println("Available Devices:");
                        for (int i = 0; i < devices.size(); i++) {
                            System.out.println((i + 1) + ". " + devices.get(i).getName());
                        }
                        System.out.print("Select device to add: ");
                        int devChoice = Integer.parseInt(scanner.nextLine()) - 1;
                        if (devChoice >= 0 && devChoice < devices.size()) {
                            automations.get(autoChoice).addDevice(devices.get(devChoice));
                            System.out.println("Device added to automation.");
                        }
                    }
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void manageUsers() {
        if (currentUser instanceof Admin) {
            System.out.println("\n=== User Management ===");
            for (int i = 0; i < users.size(); i++) {
                User user = users.get(i);
                System.out.println((i + 1) + ". " + user.getUsername() + 
                        " (" + (user instanceof Admin ? "Admin" : "Regular") + ")");
            }
            
            System.out.println("1. Add User");
            System.out.println("2. Remove User");
            System.out.println("3. Back");
            System.out.print("Choose an action: ");
            
            int actionChoice = Integer.parseInt(scanner.nextLine());
            switch (actionChoice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Is admin? (true/false): ");
                    boolean isAdmin = Boolean.parseBoolean(scanner.nextLine());
                    
                    if (isAdmin) {
                        users.add(new Admin(username, password));
                    } else {
                        users.add(new RegularUser(username, password));
                    }
                    System.out.println("User added successfully.");
                    break;
                case 2:
                    System.out.print("Select user to remove: ");
                    int userIndex = Integer.parseInt(scanner.nextLine()) - 1;
                    if (userIndex >= 0 && userIndex < users.size()) {
                        String removedUser = users.remove(userIndex).getUsername();
                        System.out.println(removedUser + " removed successfully.");
                    }
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void saveSystemState() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("smarthome_state.dat"))) {
            oos.writeObject(devices);
            oos.writeObject(users);
            oos.writeObject(automations);
            Logger.log("System state saved successfully.");
        } catch (IOException e) {
            Logger.logError("Failed to save system state: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadSystemState() {
        File file = new File("smarthome_state.dat");
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                devices = (List<Device>) ois.readObject();
                users = (List<User>) ois.readObject();
                automations = (List<Automation>) ois.readObject();
                Logger.log("System state loaded successfully.");
            } catch (IOException | ClassNotFoundException e) {
                Logger.logError("Failed to load system state: " + e.getMessage());
            }
        }
    }
}
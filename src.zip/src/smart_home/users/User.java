package users;

public abstract class User implements Authenticable {
    protected String username;
    protected String password;
    protected String email;
    protected boolean isLoggedIn;

    // Constructor 1
    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.email = "";
        this.isLoggedIn = false;
    }

    // Constructor 2 (Overloaded)
    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.isLoggedIn = false;
    }

    @Override
    public boolean authenticate(String password) {
        isLoggedIn = this.password.equals(password);
        return isLoggedIn;
    }

    @Override
    public void changePassword(String newPassword) {
        this.password = newPassword;
        System.out.println("Password changed successfully for user " + username);
    }

    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public boolean isLoggedIn() { return isLoggedIn; }

    public void logout() {
        isLoggedIn = false;
        System.out.println(username + " logged out successfully");
    }

    // Abstract method for role-specific actions
    public abstract void displayDashboard();
}
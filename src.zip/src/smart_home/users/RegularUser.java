package users;

public class RegularUser extends User {
    private String[] favoriteDevices;

    public RegularUser(String username, String password) {
        super(username, password);
        this.favoriteDevices = new String[0];
    }

    public RegularUser(String username, String password, String email) {
        super(username, password, email);
        this.favoriteDevices = new String[0];
    }

    @Override
    public void displayDashboard() {
        System.out.println("\n=== Regular User Dashboard ===");
        System.out.println("Welcome, " + username + "!");
        System.out.println("You can control your smart home devices");
        if (favoriteDevices.length > 0) {
            System.out.println("Your favorite devices:");
            for (String device : favoriteDevices) {
                System.out.println("- " + device);
            }
        }
    }

    // Method with varargs for adding favorite devices
    public void addFavoriteDevices(String... devices) {
        String[] newFavorites = new String[favoriteDevices.length + devices.length];
        System.arraycopy(favoriteDevices, 0, newFavorites, 0, favoriteDevices.length);
        System.arraycopy(devices, 0, newFavorites, favoriteDevices.length, devices.length);
        favoriteDevices = newFavorites;
        System.out.println("Added " + devices.length + " favorite devices");
    }
}
package users;

// Interface for authentication
public interface Authenticable {
    boolean authenticate(String password);
    void changePassword(String newPassword);
}
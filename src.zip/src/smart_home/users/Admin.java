package users;

public class Admin extends User {
    private int accessLevel;

    public Admin(String username, String password) {
        super(username, password);
        this.accessLevel = 1;
    }

    public Admin(String username, String password, String email, int accessLevel) {
        super(username, password, email);
        this.accessLevel = accessLevel;
    }

    @Override
    public void displayDashboard() {
        System.out.println("\n=== Admin Dashboard ===");
        System.out.println("Welcome, Admin " + username + "!");
        System.out.println("Access Level: " + accessLevel);
        System.out.println("You can manage all devices and users");
    }

    public void addUser(String username, String password) {
        System.out.println("Added new user: " + username);
    }

    public void removeUser(String username) {
        System.out.println("Removed user: " + username);
    }

    public void systemDiagnostics() {
        System.out.println("Running system diagnostics...");
        System.out.println("All systems operational");
    }
}

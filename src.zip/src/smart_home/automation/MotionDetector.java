package automation;

import devices.Device;
import devices.Light;

public class MotionDetector extends Automation implements AutomationRule, Runnable {
    private boolean motionDetected;
    private int detectionThreshold;

    public MotionDetector(String name) {
        super(name);
        this.motionDetected = false;
        this.detectionThreshold = 50;
    }

    // Overloaded constructor
    public MotionDetector(String name, int threshold) {
        super(name);
        this.motionDetected = false;
        this.detectionThreshold = threshold;
    }

    @Override
    public void trigger() {
        motionDetected = true;
        System.out.println("Motion detected by " + name);
        if (isActive) {
            execute();
        }
    }

    @Override
    public void execute() {
        if (motionDetected) {
            System.out.println("Executing motion detection automation: " + name);
            for (Device device : controlledDevices) {
                if (device instanceof Light) {
                    device.turnOn();
                    device.adjustSetting("brightness", 80);
                }
            }
            motionDetected = false;
        }
    }

    @Override
    public String getDescription() {
        return "Turns on lights when motion is detected";
    }

    // Thread implementation for continuous monitoring
    @Override
    public void run() {
        System.out.println("Starting motion detection monitoring...");
        while (true) {
            try {
                // Simulate random motion detection
                if (Math.random() * 100 > (100 - detectionThreshold)) {
                    trigger();
                }
                Thread.sleep(5000); // Check every 5 seconds
            } catch (InterruptedException e) {
                System.out.println("Motion detection monitoring interrupted");
                break;
            }
        }
    }
}
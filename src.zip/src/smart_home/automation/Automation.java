package automation;

import devices.Device;

import java.util.ArrayList;
import java.util.List;

// Abstract automation class
public abstract class Automation {
    /**
	 * 
	 */
	public String name;
    public boolean isActive;
    protected List<Device> controlledDevices;

    public Automation(String name) {
        this.setName(name);
        this.isActive = true;
        this.controlledDevices = new ArrayList<>();
    }

    public void addDevice(Device device) {
        controlledDevices.add(device);
    }

    public void removeDevice(Device device) {
        controlledDevices.remove(device);
    }

    public void setActive(boolean active) {
        isActive = active;
        System.out.println("Automation " + getName() + " is now " + (active ? "active" : "inactive"));
    }
    
    public boolean getIsActive() {
    	return this.isActive;
    }
    public abstract void execute();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

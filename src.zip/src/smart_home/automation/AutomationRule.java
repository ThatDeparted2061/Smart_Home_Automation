package automation;


// Interface for automation rules
public interface AutomationRule {
    void trigger();
    String getDescription();
}



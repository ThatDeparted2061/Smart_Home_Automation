package devices;

public class SmartPlug extends Device {
    private double currentPowerUsage; // in kW
    private boolean hasDeviceConnected;

    public SmartPlug(String name, String location) {
        super(name, location, 0);
        this.currentPowerUsage = 0;
        this.hasDeviceConnected = false;
    }

    // Overloaded constructor
    public SmartPlug(String name, String location, double initialPower) {
        super(name, location, initialPower);
        this.currentPowerUsage = initialPower;
        this.hasDeviceConnected = initialPower > 0;
    }

    @Override
    public void turnOn() {
        isOn = true;
        System.out.println(name + " smart plug turned ON");
    }

    @Override
    public void turnOff() {
        isOn = false;
        currentPowerUsage = 0;
        System.out.println(name + " smart plug turned OFF");
    }

    @Override
    public String getStatus() {
        return String.format("%s Smart Plug - Status: %s, Power Usage: %.2f kW, Device Connected: %s",
                name, isOn ? "ON" : "OFF", currentPowerUsage, hasDeviceConnected ? "YES" : "NO");
    }

    @Override
    public void adjustSetting(String setting, Object value) {
        if (setting.equalsIgnoreCase("power") && value instanceof Double) {
            currentPowerUsage = (Double) value;
            powerConsumption = currentPowerUsage;
            hasDeviceConnected = currentPowerUsage > 0;
            System.out.println(name + " power usage set to " + currentPowerUsage + " kW");
        } else {
            System.out.println("Invalid setting for Smart Plug");
        }
    }

    // Method to simulate device connection
    public void connectDevice(double devicePower) {
        if (isOn) {
            currentPowerUsage = devicePower;
            powerConsumption = devicePower;
            hasDeviceConnected = true;
            System.out.println(name + " connected to a device using " + devicePower + " kW");
        } else {
            System.out.println("Cannot connect device - smart plug is OFF");
        }
    }
}
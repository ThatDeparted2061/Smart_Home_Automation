package devices;

public class SecurityCamera extends Device {
    private boolean isRecording;
    private boolean motionDetection;
    private String recordingQuality; // HD, FullHD, 4K

    public SecurityCamera(String name, String location) {
        super(name, location, 0.1); // 0.1 kW power consumption
        this.isRecording = false;
        this.motionDetection = true;
        this.recordingQuality = "HD";
    }

    // Overloaded constructor
    public SecurityCamera(String name, String location, boolean motionDetection) {
        super(name, location, 0.1);
        this.isRecording = false;
        this.motionDetection = motionDetection;
        this.recordingQuality = "HD";
    }

    @Override
    public void turnOn() {
        isOn = true;
        System.out.println(name + " camera turned ON");
    }

    @Override
    public void turnOff() {
        isOn = false;
        isRecording = false;
        System.out.println(name + " camera turned OFF");
    }

    @Override
    public String getStatus() {
        return String.format("%s Camera - Status: %s, Recording: %s, Motion Detection: %s, Quality: %s, Power: %.2f kW",
                name, isOn ? "ON" : "OFF", isRecording ? "ON" : "OFF", 
                motionDetection ? "ON" : "OFF", recordingQuality, isOn ? powerConsumption : 0);
    }

    @Override
    public void adjustSetting(String setting, Object value) {
        switch (setting.toLowerCase()) {
            case "recording":
                if (value instanceof Boolean) {
                    isRecording = (Boolean) value;
                    System.out.println(name + " recording " + (isRecording ? "started" : "stopped"));
                }
                break;
            case "motiondetection":
                if (value instanceof Boolean) {
                    motionDetection = (Boolean) value;
                    System.out.println(name + " motion detection " + (motionDetection ? "ON" : "OFF"));
                }
                break;
            case "quality":
                if (value instanceof String) {
                    recordingQuality = (String) value;
                    System.out.println(name + " recording quality set to " + recordingQuality);
                }
                break;
            default:
                System.out.println("Invalid setting for Security Camera");
        }
    }

    public void detectMotion() {
        if (motionDetection && isOn) {
            System.out.println("Motion detected by " + name + "!");
            isRecording = true;
            // This would trigger notifications in a real system
        }
    }
}
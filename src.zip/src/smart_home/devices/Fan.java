package devices;

public class Fan extends Device {
    private int speed; // 0-5
    private boolean oscillation;

    public Fan(String name, String location) {
        super(name, location, 0.075); // 0.075 kW power consumption
        this.speed = 3;
        this.oscillation = false;
    }

    // Overloaded constructor
    public Fan(String name, String location, int initialSpeed) {
        super(name, location, 0.075);
        this.speed = initialSpeed;
        this.oscillation = false;
    }

    @Override
    public void turnOn() {
        isOn = true;
        System.out.println(name + " fan turned ON at speed " + speed);
    }

    @Override
    public void turnOff() {
        isOn = false;
        System.out.println(name + " fan turned OFF");
    }

    @Override
    public String getStatus() {
        return String.format("%s Fan - Status: %s, Speed: %d, Oscillation: %s, Power: %.2f kW",
                name, isOn ? "ON" : "OFF", speed, oscillation ? "ON" : "OFF", isOn ? powerConsumption : 0);
    }

    @Override
    public void adjustSetting(String setting, Object value) {
        switch (setting.toLowerCase()) {
            case "speed":
                if (value instanceof Integer) {
                    speed = (int) value;
                    System.out.println(name + " fan speed set to " + speed);
                }
                break;
            case "oscillation":
                if (value instanceof Boolean) {
                    oscillation = (Boolean) value;
                    System.out.println(name + " oscillation " + (oscillation ? "ON" : "OFF"));
                }
                break;
            default:
                System.out.println("Invalid setting for Fan device");
        }
    }

    // Method overloading - adjust speed with varargs
    public void adjustSpeed(int... speeds) {
        if (speeds.length > 0) {
            speed = speeds[0];
            System.out.println(name + " fan speed set to " + speed);
        } else {
            speed = 3; // default
            System.out.println(name + " fan speed reset to default (3)");
        }
    }
}
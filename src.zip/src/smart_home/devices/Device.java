package devices;


// Abstract class representing a generic smart device
public abstract class Device {
    protected String name;
    protected String location;
    protected boolean isOn;
    protected double powerConsumption;

    // Constructor 1 - Basic
    public Device(String name) {
        this.name = name;
        this.isOn = false;
        this.powerConsumption = 0;
        this.location = "Unknown";
    }

    // Constructor 2 - Detailed (Overloaded constructor)
    public Device(String name, String location, double powerConsumption) {
        this.name = name;
        this.location = location;
        this.powerConsumption = powerConsumption;
        this.isOn = false;
    }

    // Abstract methods
    public abstract void turnOn();
    public abstract void turnOff();
    public abstract String getStatus();
    public abstract void adjustSetting(String setting, Object value);

    // Getters and setters
    public String getName() { return name; }
    public String getLocation() { return location; }
    public boolean isOn() { return isOn; }
    public double getPowerConsumption() { return powerConsumption; }

    // Method overloading example - adjustSetting with different parameters
    public void adjustSetting(String setting) {
        adjustSetting(setting, null);
    }
}
package devices;

public class AC extends Device {
    private int temperature; // in °C
    private String mode; // Cool, Heat, Auto, Fan
    private int fanSpeed; // 1-5

    public AC(String name, String location) {
        super(name, location, 1.5); // 1.5 kW power consumption
        this.temperature = 24;
        this.mode = "Cool";
        this.fanSpeed = 3;
    }

    // Overloaded constructor
    public AC(String name, String location, int initialTemp) {
        super(name, location, 1.5);
        this.temperature = initialTemp;
        this.mode = "Cool";
        this.fanSpeed = 3;
    }

    @Override
    public void turnOn() {
        isOn = true;
        System.out.println(name + " AC turned ON at " + temperature + "°C");
    }

    @Override
    public void turnOff() {
        isOn = false;
        System.out.println(name + " AC turned OFF");
    }

    @Override
    public String getStatus() {
        return String.format("%s AC - Status: %s, Temp: %d°C, Mode: %s, Fan: %d, Power: %.2f kW",
                name, isOn ? "ON" : "OFF", temperature, mode, fanSpeed, isOn ? powerConsumption : 0);
    }

    @Override
    public void adjustSetting(String setting, Object value) {
        switch (setting.toLowerCase()) {
            case "temperature":
                if (value instanceof Integer) {
                    temperature = (int) value;
                    System.out.println(name + " temperature set to " + temperature + "°C");
                }
                break;
            case "mode":
                if (value instanceof String) {
                    mode = (String) value;
                    System.out.println(name + " mode changed to " + mode);
                }
                break;
            case "fanspeed":
                if (value instanceof Integer) {
                    fanSpeed = (int) value;
                    System.out.println(name + " fan speed set to " + fanSpeed);
                }
                break;
            default:
                System.out.println("Invalid setting for AC device");
        }
    }

    // Method overloading - adjust temperature with varargs
    public void adjustTemperature(int... temps) {
        if (temps.length > 0) {
            temperature = temps[0];
            System.out.println(name + " temperature set to " + temperature + "°C");
        } else {
            temperature = 24; // default
            System.out.println(name + " temperature reset to default (24°C)");
        }
    }
}
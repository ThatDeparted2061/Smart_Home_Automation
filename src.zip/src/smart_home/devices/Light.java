package devices;

public class Light extends Device {
    private int brightness; // 0-100%
    private String color; // RGB color value

    public Light(String name, String location) {
        super(name, location, 0.05); // 0.05 kW power consumption
        this.brightness = 50;
        this.color = "White";
    }

    // Overloaded constructor
    public Light(String name, String location, String initialColor) {
        super(name, location, 0.05);
        this.brightness = 50;
        this.color = initialColor;
    }

    @Override
    public void turnOn() {
        isOn = true;
        System.out.println(name + " light turned ON");
    }

    @Override
    public void turnOff() {
        isOn = false;
        System.out.println(name + " light turned OFF");
    }

    @Override
    public String getStatus() {
        return String.format("%s Light - Status: %s, Brightness: %d%%, Color: %s, Power: %.2f kW",
                name, isOn ? "ON" : "OFF", brightness, color, isOn ? powerConsumption : 0);
    }

    @Override
    public void adjustSetting(String setting, Object value) {
        switch (setting.toLowerCase()) {
            case "brightness":
                if (value instanceof Integer) {
                    brightness = (int) value;
                    System.out.println(name + " brightness set to " + brightness + "%");
                }
                break;
            case "color":
                if (value instanceof String) {
                    color = (String) value;
                    System.out.println(name + " color changed to " + color);
                }
                break;
            default:
                System.out.println("Invalid setting for Light device");
        }
    }

    // Method overloading - adjust brightness with varargs
    public void adjustBrightness(int... levels) {
        if (levels.length > 0) {
            brightness = levels[0];
            System.out.println(name + " brightness set to " + brightness + "%");
        } else {
            brightness = 50; // default
            System.out.println(name + " brightness reset to default (50%)");
        }
    }

    // Nested class for Light Modes
    public static class LightMode {
        public static final String DAYLIGHT = "Daylight";
        public static final String WARM = "Warm";
        public static final String COOL = "Cool";
        public static final String NIGHT = "Night";
    }
}